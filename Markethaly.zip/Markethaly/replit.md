# Markethaly - Marketing Campaign Management Platform

## Project Overview
An elegant Egyptian market-focused business platform for marketing solutions with user dashboards and business listings. Built as a comprehensive tool for startup founders to create and track marketing campaigns with data export capabilities.

## Key Features
- Customer-facing frontend with elegant design
- Admin dashboard for campaign management
- AI chatbot for customer inquiries
- Marketing campaign creation and tracking
- Data export capabilities
- User authentication and dashboards
- Business listings and marketplace
- Performance analytics

## Tech Stack
- Frontend: React with Vite, TailwindCSS, Wouter routing
- Backend: Express.js with TypeScript
- Database: In-memory storage (MemStorage)
- UI Components: Radix UI + Shadcn
- State Management: TanStack Query
- Forms: React Hook Form with Zod validation

## Project Structure
- `/shared/schema.ts` - Data models and types
- `/server/` - Backend API and storage
- `/client/` - Frontend React application
- `/client/src/components/` - Reusable UI components
- `/client/src/pages/` - Application pages

## User Preferences
- High-end, elegant design aesthetic
- Egyptian market focus
- Professional and trustworthy appearance
- Mobile-responsive design

## Recent Changes
- Initial project setup with full-stack architecture
- Created comprehensive data schemas for campaigns and users
- Implemented customer-facing interface with AI chatbot
- Added admin dashboard for campaign management