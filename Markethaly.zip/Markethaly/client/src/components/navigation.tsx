import { User } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Link } from "wouter";
import Logo from "@/components/logo";

interface NavigationProps {
  user: User | null;
  onLogout: () => void;
}

export default function Navigation({ user, onLogout }: NavigationProps) {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-black/95 backdrop-blur-xl border-b border-egyptian-gold/20 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div className="flex items-center">
            <Link href="/" className="flex-shrink-0">
              <div className="flex items-center space-x-3">
                <Logo size="md" />
                <h1 className="text-3xl font-bold text-egyptian-gold">Markethaly</h1>
              </div>
            </Link>
            <div className="hidden md:block ml-12">
              <div className="flex items-center space-x-2">
                <Link href="/dashboard" className="text-egyptian-gold hover:text-white px-4 py-3 text-sm font-semibold transition-all duration-300 hover:bg-white/10 rounded-lg">
                  Dashboard
                </Link>
                <Link href="/services" className="text-gray-300 hover:text-egyptian-gold px-4 py-3 text-sm font-medium transition-all duration-300 hover:bg-white/10 rounded-lg">
                  Services
                </Link>
                <Link href="/portfolio" className="text-gray-300 hover:text-egyptian-gold px-4 py-3 text-sm font-medium transition-all duration-300 hover:bg-white/10 rounded-lg">
                  Portfolio
                </Link>
                <Link href="/contact" className="text-gray-300 hover:text-egyptian-gold px-4 py-3 text-sm font-medium transition-all duration-300 hover:bg-white/10 rounded-lg">
                  Contact
                </Link>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-6">
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="flex items-center space-x-3 p-2">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user.profileImage || ""} alt={user.businessName || user.email} />
                      <AvatarFallback className="bg-egyptian-gold text-white">
                        {(user.businessName || user.email).charAt(0).toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <span className="hidden md:block text-sm font-medium text-gray-700">
                      {user.businessName || user.email}
                    </span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>My Account</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem>
                    <Link href="/dashboard" className="flex items-center w-full">
                      <i className="fas fa-tachometer-alt mr-2"></i>
                      Dashboard
                    </Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <i className="fas fa-user mr-2"></i>
                    Profile
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <i className="fas fa-cog mr-2"></i>
                    Settings
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={onLogout} className="text-red-600">
                    <i className="fas fa-sign-out-alt mr-2"></i>
                    Sign Out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="flex items-center space-x-2">
                <Link href="/login">
                  <Button variant="ghost" className="text-gray-300 hover:text-egyptian-gold font-semibold">
                    Sign In
                  </Button>
                </Link>
                <Link href="/register">
                  <Button className="bg-gradient-to-r from-egyptian-gold to-warm-gold hover:from-warm-gold hover:to-egyptian-gold text-egyptian-navy font-bold px-6 py-2 rounded-xl shadow-lg transform hover:scale-105 transition-all duration-300">
                    Get Started
                  </Button>
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
