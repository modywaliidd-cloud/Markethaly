import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";

export default function DataExport() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-egyptian-navy mb-4">Advanced Data Export & Analytics</h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Export comprehensive campaign data and gain deep insights into your marketing performance
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {/* Export Options */}
          <Card className="border-2 border-gray-100 hover:border-egyptian-blue transition-colors">
            <CardContent className="p-6">
              <div className="bg-egyptian-blue/10 rounded-lg p-3 w-fit mb-4">
                <i className="fas fa-file-csv text-2xl text-egyptian-blue"></i>
              </div>
              <h3 className="text-xl font-semibold text-egyptian-navy mb-3">CSV Export</h3>
              <p className="text-gray-600 mb-4">Export campaign data in CSV format for Excel analysis and reporting</p>
              <Button className="w-full bg-egyptian-blue hover:bg-egyptian-navy text-white">
                Export CSV
              </Button>
            </CardContent>
          </Card>

          <Card className="border-2 border-gray-100 hover:border-egyptian-gold transition-colors">
            <CardContent className="p-6">
              <div className="bg-egyptian-gold/10 rounded-lg p-3 w-fit mb-4">
                <i className="fas fa-file-pdf text-2xl text-egyptian-gold"></i>
              </div>
              <h3 className="text-xl font-semibold text-egyptian-navy mb-3">PDF Reports</h3>
              <p className="text-gray-600 mb-4">Generate professional PDF reports with charts and insights</p>
              <Button className="w-full bg-egyptian-gold hover:bg-warm-gold text-white">
                Generate Report
              </Button>
            </CardContent>
          </Card>

          <Card className="border-2 border-gray-100 hover:border-green-500 transition-colors">
            <CardContent className="p-6">
              <div className="bg-green-100 rounded-lg p-3 w-fit mb-4">
                <i className="fas fa-file-excel text-2xl text-green-600"></i>
              </div>
              <h3 className="text-xl font-semibold text-egyptian-navy mb-3">Excel Dashboard</h3>
              <p className="text-gray-600 mb-4">Export interactive Excel dashboards with pivot tables and charts</p>
              <Button className="w-full bg-green-600 hover:bg-green-700 text-white">
                Export Excel
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Export Filters */}
        <div className="mt-12 bg-gray-50 rounded-xl p-8">
          <h3 className="text-2xl font-semibold text-egyptian-navy mb-6">Customize Your Export</h3>
          <div className="grid md:grid-cols-3 gap-6">
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Date Range</Label>
              <Select>
                <SelectTrigger className="focus:ring-2 focus:ring-egyptian-blue focus:border-transparent">
                  <SelectValue placeholder="Last 30 days" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="30days">Last 30 days</SelectItem>
                  <SelectItem value="3months">Last 3 months</SelectItem>
                  <SelectItem value="6months">Last 6 months</SelectItem>
                  <SelectItem value="custom">Custom range</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Campaign Status</Label>
              <Select>
                <SelectTrigger className="focus:ring-2 focus:ring-egyptian-blue focus:border-transparent">
                  <SelectValue placeholder="All campaigns" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All campaigns</SelectItem>
                  <SelectItem value="active">Active only</SelectItem>
                  <SelectItem value="completed">Completed only</SelectItem>
                  <SelectItem value="paused">Paused only</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="block text-sm font-medium text-gray-700 mb-2">Data Fields</Label>
              <Select>
                <SelectTrigger className="focus:ring-2 focus:ring-egyptian-blue focus:border-transparent">
                  <SelectValue placeholder="All data fields" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All data fields</SelectItem>
                  <SelectItem value="performance">Performance metrics</SelectItem>
                  <SelectItem value="financial">Financial data</SelectItem>
                  <SelectItem value="audience">Audience insights</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
