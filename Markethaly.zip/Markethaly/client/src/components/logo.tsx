interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export default function Logo({ className = "", size = 'md' }: LogoProps) {
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-10 h-10', 
    lg: 'w-16 h-16'
  };

  const iconSizes = {
    sm: 'text-sm',
    md: 'text-lg',
    lg: 'text-2xl'
  };

  return (
    <div className={`${sizeClasses[size]} bg-gradient-to-br from-egyptian-gold to-warm-gold rounded-xl flex items-center justify-center ${className}`}>
      <i className={`fas fa-crown text-white ${iconSizes[size]}`}></i>
    </div>
  );
}