import { useState, useRef, useEffect } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { User, ChatMessage } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ChatWidgetProps {
  user: User | null;
}

export default function ChatWidget({ user }: ChatWidgetProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [message, setMessage] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  // Fetch chat messages for logged-in users
  const { data: chatHistory = [] } = useQuery({
    queryKey: ['/api/chat', user?.id],
    enabled: !!user?.id,
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatHistory]);

  // Send message mutation
  const sendMessageMutation = useMutation({
    mutationFn: async (messageText: string) => {
      const response = await apiRequest("POST", "/api/chat", {
        message: messageText,
        userId: user?.id,
        isUser: true,
      });
      return response.json();
    },
    onSuccess: (data) => {
      if (user?.id) {
        queryClient.invalidateQueries({ queryKey: ['/api/chat', user.id] });
      } else {
        // For non-logged-in users, add messages to local state
        setLocalMessages(prev => [
          ...prev,
          { id: Date.now().toString(), message, isUser: true, userId: null, timestamp: new Date() },
          { id: (Date.now() + 1).toString(), message: data.response, isUser: false, userId: null, timestamp: new Date() }
        ]);
      }
      setMessage("");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Local messages state for non-logged-in users
  const [localMessages, setLocalMessages] = useState<ChatMessage[]>([
    {
      id: "welcome",
      message: "Hello! I'm your Markethaly assistant. How can I help you optimize your marketing campaigns today?",
      isUser: false,
      userId: null,
      timestamp: new Date(),
    }
  ]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;

    if (!user) {
      // For non-logged-in users, add user message first
      setLocalMessages(prev => [
        ...prev,
        { id: Date.now().toString(), message, isUser: true, userId: null, timestamp: new Date() }
      ]);
    }

    sendMessageMutation.mutate(message);
  };

  const messages = user ? (chatHistory as ChatMessage[]) : localMessages;

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Chat Toggle Button */}
      <Button
        onClick={() => setIsOpen(!isOpen)}
        className="bg-egyptian-gold hover:bg-warm-gold text-white rounded-full p-4 shadow-lg transition-all duration-300 transform hover:scale-110 animate-pulse"
        size="icon"
      >
        <i className="fas fa-comments text-xl"></i>
      </Button>

      {/* Chat Window */}
      {isOpen && (
        <Card className="absolute bottom-16 right-0 w-80 shadow-2xl animate-slide-up">
          <CardHeader className="bg-gradient-to-r from-egyptian-navy to-egyptian-blue text-white p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="w-8 h-8 bg-egyptian-gold rounded-full flex items-center justify-center">
                  <i className="fas fa-robot text-sm"></i>
                </div>
                <div>
                  <CardTitle className="text-sm font-semibold">Markethaly Assistant</CardTitle>
                  <p className="text-xs text-gray-200">Powered by AI</p>
                </div>
              </div>
              <Button
                onClick={() => setIsOpen(false)}
                variant="ghost"
                size="sm"
                className="text-white hover:text-gray-200 hover:bg-white/10 p-1"
              >
                <i className="fas fa-times"></i>
              </Button>
            </div>
          </CardHeader>

          <CardContent className="p-0">
            {/* Chat Messages */}
            <div className="h-80 overflow-y-auto p-4 space-y-4">
              {messages.map((msg: ChatMessage) => (
                <div key={msg.id} className={`flex items-start space-x-2 ${msg.isUser ? 'justify-end' : ''}`}>
                  {!msg.isUser && (
                    <div className="w-6 h-6 bg-egyptian-gold rounded-full flex items-center justify-center flex-shrink-0">
                      <i className="fas fa-robot text-xs text-white"></i>
                    </div>
                  )}
                  <div className={`rounded-lg p-3 max-w-xs ${
                    msg.isUser 
                      ? 'bg-egyptian-blue text-white' 
                      : 'bg-gray-100 text-gray-800'
                  }`}>
                    <p className="text-sm">{msg.message}</p>
                  </div>
                </div>
              ))}
              {sendMessageMutation.isPending && (
                <div className="flex items-start space-x-2">
                  <div className="w-6 h-6 bg-egyptian-gold rounded-full flex items-center justify-center flex-shrink-0">
                    <i className="fas fa-robot text-xs text-white"></i>
                  </div>
                  <div className="bg-gray-100 rounded-lg p-3 max-w-xs">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Chat Input */}
            <div className="border-t border-gray-200 p-4">
              <form onSubmit={handleSendMessage} className="flex space-x-2">
                <Input
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Type your message..."
                  className="flex-1 focus:ring-2 focus:ring-egyptian-blue focus:border-transparent"
                  disabled={sendMessageMutation.isPending}
                />
                <Button
                  type="submit"
                  disabled={sendMessageMutation.isPending || !message.trim()}
                  className="bg-egyptian-blue hover:bg-egyptian-navy text-white px-4 py-2"
                >
                  <i className="fas fa-paper-plane text-sm"></i>
                </Button>
              </form>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
