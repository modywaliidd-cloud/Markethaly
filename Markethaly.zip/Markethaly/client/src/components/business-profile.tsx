import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

export default function BusinessProfile() {
  return (
    <section id="profile" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-4xl font-bold text-egyptian-navy mb-6">Build Your Professional Presence</h2>
            <p className="text-xl text-gray-600 mb-8">
              Create a compelling business profile that showcases your services, 
              portfolio, and expertise to attract high-value clients.
            </p>
            <div className="space-y-4">
              <div className="flex items-center space-x-4">
                <div className="bg-egyptian-gold rounded-full p-2">
                  <i className="fas fa-check text-white"></i>
                </div>
                <span className="text-gray-700">Professional portfolio showcase</span>
              </div>
              <div className="flex items-center space-x-4">
                <div className="bg-egyptian-gold rounded-full p-2">
                  <i className="fas fa-check text-white"></i>
                </div>
                <span className="text-gray-700">Client testimonials & reviews</span>
              </div>
              <div className="flex items-center space-x-4">
                <div className="bg-egyptian-gold rounded-full p-2">
                  <i className="fas fa-check text-white"></i>
                </div>
                <span className="text-gray-700">Service packages & pricing</span>
              </div>
            </div>
          </div>

          {/* Business Profile Card */}
          <Card className="shadow-xl border border-gray-100">
            <CardContent className="p-8">
              <div className="text-center mb-6">
                <div className="relative inline-block">
                  <img 
                    src="https://images.unsplash.com/photo-1560250097-0b93528c311a?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=200" 
                    alt="Professional business owner in modern Egyptian office" 
                    className="w-20 h-20 rounded-full object-cover border-4 border-egyptian-gold"
                  />
                  <div className="absolute -top-1 -right-1 bg-green-500 w-6 h-6 rounded-full border-2 border-white flex items-center justify-center">
                    <i className="fas fa-crown text-white text-xs"></i>
                  </div>
                </div>
                <h3 className="text-xl font-bold text-egyptian-navy mt-4">Elite Marketing Solutions</h3>
                <p className="text-gray-600">Cairo, Egypt</p>
                <div className="flex items-center justify-center mt-2">
                  <div className="flex text-egyptian-gold">
                    {[...Array(5)].map((_, i) => (
                      <i key={i} className="fas fa-star"></i>
                    ))}
                  </div>
                  <span className="text-sm text-gray-600 ml-2">(4.9 • 127 reviews)</span>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 mb-6 text-center">
                <div>
                  <div className="text-2xl font-bold text-egyptian-navy">156</div>
                  <div className="text-xs text-gray-600">Projects</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-egyptian-navy">98%</div>
                  <div className="text-xs text-gray-600">Success Rate</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-egyptian-navy">5+</div>
                  <div className="text-xs text-gray-600">Years Exp</div>
                </div>
              </div>

              <div className="space-y-3">
                <div className="bg-gradient-to-r from-egyptian-navy to-egyptian-blue rounded-lg p-3 text-white">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Digital Marketing Strategy</span>
                    <Badge variant="secondary" className="bg-white/20 text-white">Premium</Badge>
                  </div>
                </div>
                <div className="bg-gradient-to-r from-egyptian-gold to-warm-gold rounded-lg p-3 text-white">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Social Media Management</span>
                    <Badge variant="secondary" className="bg-white/20 text-white">Popular</Badge>
                  </div>
                </div>
              </div>

              <Button className="w-full bg-egyptian-blue hover:bg-egyptian-navy text-white py-3 rounded-lg font-medium mt-6">
                Edit Profile
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
