import { User } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

interface HeroSectionProps {
  user: User | null;
}

export default function HeroSection({ user }: HeroSectionProps) {
  return (
    <section className="pt-16 gradient-bg egyptian-pattern min-h-screen flex items-center">
      <div className="starry-night"></div>
      <div className="shooting-star"></div>
      <div className="shooting-star"></div>
      <div className="shooting-star"></div>
      <div className="shooting-star"></div>
      <div className="shooting-star"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-white animate-slide-up">
            <h1 className="text-6xl lg:text-7xl font-bold mb-8 leading-tight">
              Elevate Your 
              <span className="text-egyptian-gold"> Business</span>
              <br />Beyond Expectations
            </h1>
            <p className="text-2xl mb-12 text-gray-200 leading-relaxed font-light max-w-2xl">
              A premium marketing platform designed for visionary entrepreneurs. 
              Craft campaigns, track success, and dominate the Egyptian market with unparalleled elegance.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              {user ? (
                <Link href="/dashboard">
                  <Button className="bg-egyptian-gold hover:bg-warm-gold text-egyptian-navy px-8 py-4 text-lg font-semibold rounded-xl transition-all duration-300 transform hover:scale-105 shadow-lg">
                    Go to Dashboard
                  </Button>
                </Link>
              ) : (
                <>
                  <Link href="/register">
                    <Button className="bg-gradient-to-r from-egyptian-gold to-warm-gold hover:from-warm-gold hover:to-egyptian-gold text-egyptian-navy px-12 py-6 text-xl font-bold rounded-2xl transition-all duration-300 transform hover:scale-105 shadow-2xl">
                      Begin Your Journey
                    </Button>
                  </Link>
                  <Button 
                    variant="outline" 
                    className="border-2 border-egyptian-gold/60 bg-gray-900/80 text-egyptian-gold hover:bg-gray-800 hover:border-egyptian-gold px-12 py-6 text-xl font-semibold rounded-2xl transition-all duration-300 backdrop-blur-sm"
                  >
                    Discover More
                  </Button>
                </>
              )}
            </div>
          </div>
          <div className="relative animate-float">
            <img 
              src="https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600" 
              alt="Modern business meeting in luxurious Egyptian office" 
              className="rounded-2xl shadow-2xl"
            />
            <div className="absolute -top-6 -right-6 bg-egyptian-gold rounded-xl p-4 shadow-lg">
              <i className="fas fa-chart-line text-2xl text-egyptian-navy"></i>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
