import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import Navigation from "@/components/navigation";
import type { User } from "@shared/schema";

interface ContactProps {
  user: User | null;
  onLogout: () => void;
}

export default function Contact({ user, onLogout }: ContactProps) {
  const contactMethods = [
    {
      icon: "fas fa-phone",
      title: "Phone Support",
      details: "+20 2 1234 5678",
      description: "Call us directly for immediate assistance"
    },
    {
      icon: "fas fa-envelope",
      title: "Email Support",
      details: "hello@markethaly.com",
      description: "Get detailed responses within 24 hours"
    },
    {
      icon: "fas fa-map-marker-alt",
      title: "Office Location",
      details: "New Cairo, Egypt",
      description: "Visit our headquarters for in-person consultations"
    },
    {
      icon: "fas fa-clock",
      title: "Business Hours",
      details: "Sun - Thu: 9AM - 6PM",
      description: "Saturday: 10AM - 4PM (Closed Fridays)"
    }
  ];

  return (
    <div className="min-h-screen dark-bg">
      <Navigation user={user} onLogout={onLogout} />
      
      <div className="pt-20">
        {/* Header Section */}
        <section className="gradient-bg egyptian-pattern py-20">
          <div className="starry-night"></div>
          <div className="shooting-star"></div>
          <div className="shooting-star"></div>
          <div className="shooting-star"></div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="text-center">
              <h1 className="text-5xl lg:text-6xl font-bold mb-8 text-egyptian-gold">
                Let's Talk Business
              </h1>
              <p className="text-2xl mb-12 text-gray-300 leading-relaxed font-light max-w-3xl mx-auto">
                Need help, have questions, or ready to start? Reach out to our team directly – 
                we're here to support you with fast, friendly, and professional service.
              </p>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid lg:grid-cols-2 gap-12">
              {/* Contact Form */}
              <Card className="bg-gray-900 border border-egyptian-gold/30 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-2xl font-bold text-egyptian-gold">Send us a Message</CardTitle>
                </CardHeader>
                <CardContent>
                  <form className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="firstName" className="text-gray-300">First Name</Label>
                        <Input 
                          id="firstName" 
                          placeholder="Enter your first name"
                          className="bg-gray-800 border-gray-700 text-white placeholder-gray-400 focus:border-egyptian-gold"
                        />
                      </div>
                      <div>
                        <Label htmlFor="lastName" className="text-gray-300">Last Name</Label>
                        <Input 
                          id="lastName" 
                          placeholder="Enter your last name"
                          className="bg-gray-800 border-gray-700 text-white placeholder-gray-400 focus:border-egyptian-gold"
                        />
                      </div>
                    </div>
                    
                    <div>
                      <Label htmlFor="email" className="text-gray-300">Email Address</Label>
                      <Input 
                        id="email" 
                        type="email"
                        placeholder="your@email.com"
                        className="bg-gray-800 border-gray-700 text-white placeholder-gray-400 focus:border-egyptian-gold"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="company" className="text-gray-300">Company Name</Label>
                      <Input 
                        id="company" 
                        placeholder="Your company name"
                        className="bg-gray-800 border-gray-700 text-white placeholder-gray-400 focus:border-egyptian-gold"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="subject" className="text-gray-300">Subject</Label>
                      <Input 
                        id="subject" 
                        placeholder="What can we help you with?"
                        className="bg-gray-800 border-gray-700 text-white placeholder-gray-400 focus:border-egyptian-gold"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="message" className="text-gray-300">Message</Label>
                      <Textarea 
                        id="message" 
                        placeholder="Tell us more about your project or questions..."
                        rows={5}
                        className="bg-gray-800 border-gray-700 text-white placeholder-gray-400 focus:border-egyptian-gold"
                      />
                    </div>
                    
                    <Button className="w-full bg-gradient-to-r from-egyptian-gold to-warm-gold hover:from-warm-gold hover:to-egyptian-gold text-black font-bold py-3">
                      <i className="fas fa-paper-plane mr-2"></i>
                      Send Message
                    </Button>
                  </form>
                </CardContent>
              </Card>

              {/* Contact Information */}
              <div className="space-y-8">
                <div>
                  <h3 className="text-3xl font-bold text-egyptian-gold mb-6">Get in Touch</h3>
                  <p className="text-gray-300 text-lg leading-relaxed">
                    Ready to transform your business? Our team of marketing experts is standing by to help you 
                    achieve remarkable growth. Whether you're just starting out or looking to scale, we're here 
                    to make your success our priority.
                  </p>
                </div>

                <div className="grid gap-6">
                  {contactMethods.map((method, index) => (
                    <Card key={index} className="bg-gray-900 border border-egyptian-gold/30 hover:border-egyptian-gold/50 transition-colors">
                      <CardContent className="p-6">
                        <div className="flex items-start space-x-4">
                          <div className="w-12 h-12 bg-gradient-to-br from-egyptian-gold to-warm-gold rounded-lg flex items-center justify-center flex-shrink-0">
                            <i className={`${method.icon} text-white`}></i>
                          </div>
                          <div>
                            <h4 className="text-lg font-semibold text-egyptian-gold mb-1">{method.title}</h4>
                            <p className="text-white font-medium mb-2">{method.details}</p>
                            <p className="text-gray-400 text-sm">{method.description}</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>

                {/* CTA Card */}
                <Card className="bg-gradient-to-r from-egyptian-gold/10 to-warm-gold/10 border border-egyptian-gold/30">
                  <CardContent className="p-8 text-center">
                    <div className="w-16 h-16 mx-auto mb-4 bg-gradient-to-br from-egyptian-gold to-warm-gold rounded-full flex items-center justify-center">
                      <i className="fas fa-rocket text-2xl text-white"></i>
                    </div>
                    <h4 className="text-xl font-bold text-egyptian-gold mb-2">Ready to Get Started?</h4>
                    <p className="text-gray-300 mb-4">
                      Book a free consultation and discover how we can accelerate your business growth.
                    </p>
                    <Button variant="outline" className="border-egyptian-gold text-egyptian-gold hover:bg-egyptian-gold hover:text-black">
                      <i className="fas fa-calendar-alt mr-2"></i>
                      Schedule Free Consultation
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}