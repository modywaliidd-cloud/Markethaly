import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import Navigation from "@/components/navigation";
import type { User } from "@shared/schema";

interface PortfolioProps {
  user: User | null;
  onLogout: () => void;
}

export default function Portfolio({ user, onLogout }: PortfolioProps) {
  const projects = [
    {
      title: "Cairo Tech Summit 2024",
      industry: "Technology",
      description: "Complete digital marketing campaign for Egypt's largest tech conference",
      results: {
        reach: "250K+",
        engagement: "89%",
        roi: "340%"
      },
      image: "fas fa-laptop-code",
      status: "Completed"
    },
    {
      title: "Red Sea Resorts Brand",
      industry: "Tourism",
      description: "Luxury brand development and marketing for premium Red Sea destination",
      results: {
        reach: "180K+",
        engagement: "92%",
        roi: "280%"
      },
      image: "fas fa-umbrella-beach",
      status: "Completed"
    },
    {
      title: "Alexandria Innovation Hub",
      industry: "Startup Ecosystem",
      description: "Launch campaign for Alexandria's premier innovation and entrepreneurship center",
      results: {
        reach: "120K+",
        engagement: "85%",
        roi: "450%"
      },
      image: "fas fa-lightbulb",
      status: "Completed"
    },
    {
      title: "Nile Valley Organic Foods",
      industry: "Agriculture",
      description: "Brand positioning and digital marketing for premium organic food producer",
      results: {
        reach: "95K+",
        engagement: "94%",
        roi: "220%"
      },
      image: "fas fa-seedling",
      status: "Completed"
    },
    {
      title: "Cairo Fashion Week",
      industry: "Fashion & Events",
      description: "Comprehensive marketing strategy for Egypt's premier fashion event",
      results: {
        reach: "300K+",
        engagement: "96%",
        roi: "380%"
      },
      image: "fas fa-tshirt",
      status: "Ongoing"
    },
    {
      title: "Pyramids Heritage Tours",
      industry: "Travel & Tourism",
      description: "Digital transformation and marketing for luxury heritage tour operator",
      results: {
        reach: "150K+",
        engagement: "88%",
        roi: "310%"
      },
      image: "fas fa-map-marked-alt",
      status: "Completed"
    }
  ];

  return (
    <div className="min-h-screen dark-bg">
      <Navigation user={user} onLogout={onLogout} />
      
      <div className="pt-20">
        {/* Header Section */}
        <section className="gradient-bg egyptian-pattern py-20">
          <div className="starry-night"></div>
          <div className="shooting-star"></div>
          <div className="shooting-star"></div>
          <div className="shooting-star"></div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="text-center">
              <h1 className="text-5xl lg:text-6xl font-bold mb-8 text-egyptian-gold">
                Success Stories from the Market
              </h1>
              <p className="text-2xl mb-12 text-gray-300 leading-relaxed font-light max-w-3xl mx-auto">
                Discover how other businesses like yours have grown through Markethaly. 
                Browse featured campaigns, case studies, and real results delivered by our expert performance teams.
              </p>
            </div>
          </div>
        </section>

        {/* Portfolio Grid */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {projects.map((project, index) => (
                <Card key={index} className="bg-gray-900 border border-egyptian-gold/30 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
                  <CardHeader>
                    <div className="flex items-center justify-between mb-4">
                      <div className="w-16 h-16 bg-gradient-to-br from-egyptian-gold to-warm-gold rounded-xl flex items-center justify-center">
                        <i className={`${project.image} text-2xl text-white`}></i>
                      </div>
                      <Badge 
                        variant={project.status === 'Completed' ? 'default' : 'secondary'}
                        className={project.status === 'Completed' ? 'bg-green-600' : 'bg-yellow-600'}
                      >
                        {project.status}
                      </Badge>
                    </div>
                    <CardTitle className="text-xl font-bold text-egyptian-gold mb-2">{project.title}</CardTitle>
                    <div className="text-sm text-gray-400 mb-3">{project.industry}</div>
                    <CardDescription className="text-gray-300 leading-relaxed">
                      {project.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-3 gap-4 mb-6">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-egyptian-gold">{project.results.reach}</div>
                        <div className="text-xs text-gray-400">Reach</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-egyptian-gold">{project.results.engagement}</div>
                        <div className="text-xs text-gray-400">Engagement</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-egyptian-gold">{project.results.roi}</div>
                        <div className="text-xs text-gray-400">ROI</div>
                      </div>
                    </div>
                    <Button variant="outline" className="w-full border-egyptian-gold text-egyptian-gold hover:bg-egyptian-gold hover:text-black">
                      View Case Study
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Stats Section */}
            <div className="mt-20">
              <Card className="bg-gradient-to-r from-gray-900 to-black border border-egyptian-gold/30 p-12">
                <CardContent>
                  <div className="text-center mb-12">
                    <h3 className="text-4xl font-bold text-egyptian-gold mb-4">Proven Track Record</h3>
                    <p className="text-gray-300 text-xl max-w-2xl mx-auto">
                      Our results speak for themselves. Here's what we've achieved for businesses like yours.
                    </p>
                  </div>
                  <div className="grid md:grid-cols-4 gap-8">
                    <div className="text-center">
                      <div className="text-5xl font-bold text-egyptian-gold mb-2">50+</div>
                      <div className="text-gray-300">Successful Campaigns</div>
                    </div>
                    <div className="text-center">
                      <div className="text-5xl font-bold text-egyptian-gold mb-2">2M+</div>
                      <div className="text-gray-300">Total Reach</div>
                    </div>
                    <div className="text-center">
                      <div className="text-5xl font-bold text-egyptian-gold mb-2">91%</div>
                      <div className="text-gray-300">Average Engagement</div>
                    </div>
                    <div className="text-center">
                      <div className="text-5xl font-bold text-egyptian-gold mb-2">320%</div>
                      <div className="text-gray-300">Average ROI</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}