import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Navigation from "@/components/navigation";
import type { User } from "@shared/schema";

interface ServicesProps {
  user: User | null;
  onLogout: () => void;
}

export default function Services({ user, onLogout }: ServicesProps) {
  const services = [
    {
      icon: "fas fa-rocket",
      title: "Campaign Management",
      description: "End-to-end marketing campaign creation, execution, and optimization.",
      features: ["Strategic Planning", "Content Creation", "Performance Tracking", "ROI Analysis"]
    },
    {
      icon: "fas fa-bullhorn",
      title: "Brand Development",
      description: "Build a powerful brand presence that resonates with Egyptian market.",
      features: ["Logo Design", "Brand Strategy", "Visual Identity", "Market Positioning"]
    },
    {
      icon: "fas fa-chart-line",
      title: "Digital Marketing",
      description: "Comprehensive digital marketing solutions for maximum online impact.",
      features: ["Social Media", "Content Marketing", "SEO Optimization", "Paid Advertising"]
    },
    {
      icon: "fas fa-users",
      title: "Customer Outreach",
      description: "Connect with your target audience through personalized outreach strategies.",
      features: ["Email Marketing", "Lead Generation", "Customer Segmentation", "Engagement Analytics"]
    }
  ];

  return (
    <div className="min-h-screen dark-bg">
      <Navigation user={user} onLogout={onLogout} />
      
      <div className="pt-20">
        {/* Header Section */}
        <section className="gradient-bg egyptian-pattern py-20">
          <div className="starry-night"></div>
          <div className="shooting-star"></div>
          <div className="shooting-star"></div>
          <div className="shooting-star"></div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="text-center">
              <h1 className="text-5xl lg:text-6xl font-bold mb-8 text-egyptian-gold">
                Tailored Marketing & Growth Solutions
              </h1>
              <p className="text-2xl mb-12 text-gray-300 leading-relaxed font-light max-w-3xl mx-auto">
                Explore the full range of marketing, branding, and customer outreach services we provide. 
                Designed to help your business grow without upfront costs – we only win when you do.
              </p>
            </div>
          </div>
        </section>

        {/* Services Grid */}
        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid md:grid-cols-2 lg:grid-cols-2 gap-8 mb-16">
              {services.map((service, index) => (
                <Card key={index} className="bg-gray-900 border border-egyptian-gold/30 shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105">
                  <CardHeader className="pb-4">
                    <div className="flex items-center space-x-4 mb-4">
                      <div className="w-16 h-16 bg-gradient-to-br from-egyptian-gold to-warm-gold rounded-xl flex items-center justify-center">
                        <i className={`${service.icon} text-2xl text-white`}></i>
                      </div>
                      <div>
                        <CardTitle className="text-2xl font-bold text-egyptian-gold">{service.title}</CardTitle>
                      </div>
                    </div>
                    <CardDescription className="text-gray-300 text-lg leading-relaxed">
                      {service.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {service.features.map((feature, idx) => (
                        <div key={idx} className="flex items-center space-x-3">
                          <div className="w-2 h-2 bg-egyptian-gold rounded-full"></div>
                          <span className="text-gray-300 font-medium">{feature}</span>
                        </div>
                      ))}
                    </div>
                    <Button className="w-full mt-6 bg-egyptian-gold hover:bg-warm-gold text-black font-semibold">
                      Learn More
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* CTA Section */}
            <div className="text-center">
              <Card className="bg-gradient-to-r from-gray-900 to-black border border-egyptian-gold/30 p-12">
                <CardContent className="text-center">
                  <div className="w-20 h-20 mx-auto mb-6 bg-gradient-to-br from-egyptian-gold to-warm-gold rounded-full flex items-center justify-center">
                    <i className="fas fa-handshake text-3xl text-white"></i>
                  </div>
                  <h3 className="text-3xl font-bold text-egyptian-gold mb-4">Ready to Grow Your Business?</h3>
                  <p className="text-gray-300 text-xl mb-8 max-w-2xl mx-auto">
                    No upfront costs, no hidden fees. We succeed when you succeed. 
                    Let's build something amazing together.
                  </p>
                  <div className="flex flex-col sm:flex-row gap-4 justify-center">
                    <Button className="bg-gradient-to-r from-egyptian-gold to-warm-gold hover:from-warm-gold hover:to-egyptian-gold text-black px-8 py-4 text-lg font-bold rounded-xl">
                      Get Started Today
                    </Button>
                    <Button variant="outline" className="border-2 border-egyptian-gold text-egyptian-gold hover:bg-egyptian-gold hover:text-black px-8 py-4 text-lg font-semibold rounded-xl">
                      Schedule Consultation
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}