import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { User, Campaign } from "@shared/schema";
import Navigation from "@/components/navigation";
import ChatWidget from "@/components/chat-widget";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Progress } from "@/components/ui/progress";

interface DashboardProps {
  user: User;
  onLogout: () => void;
}

export default function Dashboard({ user, onLogout }: DashboardProps) {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const { toast } = useToast();

  // Fetch campaigns
  const { data: campaigns = [], isLoading: campaignsLoading } = useQuery({
    queryKey: ['/api/campaigns', user.id],
    enabled: !!user.id,
  });

  // Fetch stats
  const { data: stats = {} } = useQuery({
    queryKey: ['/api/stats', user.id],
    enabled: !!user.id,
  });

  // Create campaign mutation
  const createCampaignMutation = useMutation({
    mutationFn: async (campaignData: any) => {
      const response = await apiRequest("POST", "/api/campaigns", campaignData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/campaigns', user.id] });
      queryClient.invalidateQueries({ queryKey: ['/api/stats', user.id] });
      setIsCreateModalOpen(false);
      toast({
        title: "Success",
        description: "Campaign created successfully!",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create campaign",
        variant: "destructive",
      });
    },
  });

  // Export CSV mutation
  const exportCSVMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("POST", `/api/export/csv/${user.id}`, {});
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = 'campaigns.csv';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Campaign data exported successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to export data",
        variant: "destructive",
      });
    },
  });

  const handleCreateCampaign = (formData: FormData) => {
    const campaignData = {
      userId: user.id,
      name: formData.get('name') as string,
      platform: formData.get('platform') as string,
      budget: parseInt(formData.get('budget') as string),
      status: formData.get('status') as string,
    };
    createCampaignMutation.mutate(campaignData);
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'active': return 'default';
      case 'paused': return 'secondary';
      case 'completed': return 'outline';
      default: return 'default';
    }
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
  };

  return (
    <div className="min-h-screen dark-bg">
      <Navigation user={user} onLogout={onLogout} />
      
      <div className="pt-16">
        {/* Hero Section */}
        <section className="gradient-bg egyptian-pattern py-20">
          <div className="starry-night"></div>
          <div className="shooting-star"></div>
          <div className="shooting-star"></div>
          <div className="shooting-star"></div>
          <div className="shooting-star"></div>
          <div className="shooting-star"></div>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
            <div className="text-center">
              <h1 className="text-4xl lg:text-5xl font-bold mb-4 text-egyptian-gold">
                Welcome back, {user.businessName || 'Marketing Pro'}!
              </h1>
              <p className="text-xl text-gray-300 mb-8">
                Track your campaigns, analyze performance, and grow your business.
              </p>
            </div>
          </div>
        </section>

        {/* Stats Cards */}
        <section className="py-12 -mt-10 relative z-10">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
              <Card className="bg-gradient-to-br from-gray-900 to-black text-egyptian-gold shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 border border-egyptian-gold/30">
                <CardContent className="p-8">
                  <div className="flex items-center justify-between mb-6">
                    <div className="bg-egyptian-gold/20 rounded-xl p-4">
                      <i className="fas fa-rocket text-3xl text-egyptian-gold"></i>
                    </div>
                    <span className="text-green-400 text-sm font-semibold">+12%</span>
                  </div>
                  <h3 className="text-4xl font-bold mb-3 text-egyptian-gold">5</h3>
                  <p className="text-gray-300 font-medium">Active Campaigns</p>
                  <p className="text-xs text-gray-400 mt-2">2 launching this week</p>
                </CardContent>
              </Card>
              
              <Card className="bg-gradient-to-br from-gray-900 to-black text-egyptian-gold shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 border border-egyptian-gold/30">
                <CardContent className="p-8">
                  <div className="flex items-center justify-between mb-6">
                    <div className="bg-egyptian-gold/20 rounded-xl p-4">
                      <i className="fas fa-users text-3xl text-egyptian-gold"></i>
                    </div>
                    <span className="text-green-400 text-sm font-semibold">+24%</span>
                  </div>
                  <h3 className="text-4xl font-bold mb-3 text-egyptian-gold">127.5K</h3>
                  <p className="text-gray-300 font-medium">Total Reach</p>
                  <p className="text-xs text-gray-400 mt-2">Egyptian market focus</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-gray-900 to-black text-egyptian-gold shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 border border-egyptian-gold/30">
                <CardContent className="p-8">
                  <div className="flex items-center justify-between mb-6">
                    <div className="bg-egyptian-gold/20 rounded-xl p-4">
                      <i className="fas fa-chart-line text-3xl text-egyptian-gold"></i>
                    </div>
                    <span className="text-green-400 text-sm font-semibold">+15%</span>
                  </div>
                  <h3 className="text-4xl font-bold mb-3 text-egyptian-gold">89%</h3>
                  <p className="text-gray-300 font-medium">Performance</p>
                  <p className="text-xs text-gray-400 mt-2">Above industry average</p>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-gray-900 to-black text-egyptian-gold shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-105 border border-egyptian-gold/30">
                <CardContent className="p-8">
                  <div className="flex items-center justify-between mb-6">
                    <div className="bg-egyptian-gold/20 rounded-xl p-4">
                      <i className="fas fa-trophy text-3xl text-egyptian-gold"></i>
                    </div>
                    <span className="text-green-400 text-sm font-semibold">+22%</span>
                  </div>
                  <h3 className="text-4xl font-bold mb-3 text-egyptian-gold">$45.2K</h3>
                  <p className="text-gray-300 font-medium">Revenue Generated</p>
                  <p className="text-xs text-gray-400 mt-2">This month</p>
                </CardContent>
              </Card>
            </div>

            {/* Campaign Management */}
            <div className="grid lg:grid-cols-3 gap-8">
              {/* Campaign List */}
              <div className="lg:col-span-2">
                <Card className="shadow-lg bg-gray-900 border border-egyptian-gold/30">
                  <CardHeader className="border-b border-egyptian-gold/20 flex flex-row items-center justify-between space-y-0 pb-4">
                    <CardTitle className="text-xl font-semibold text-egyptian-gold">Active Campaigns</CardTitle>
                    <div className="flex space-x-3">
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => exportCSVMutation.mutate()}
                        disabled={exportCSVMutation.isPending}
                      >
                        {exportCSVMutation.isPending ? (
                          <i className="fas fa-spinner fa-spin mr-2"></i>
                        ) : (
                          <i className="fas fa-download mr-2"></i>
                        )}
                        Export
                      </Button>
                      <Dialog open={isCreateModalOpen} onOpenChange={setIsCreateModalOpen}>
                        <DialogTrigger asChild>
                          <Button className="bg-egyptian-gold hover:bg-warm-gold text-egyptian-navy">
                            <i className="fas fa-plus mr-2"></i>New Campaign
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="sm:max-w-[425px]">
                          <form onSubmit={(e) => { e.preventDefault(); handleCreateCampaign(new FormData(e.currentTarget)); }}>
                            <DialogHeader>
                              <DialogTitle>Create New Campaign</DialogTitle>
                              <DialogDescription>
                                Set up a new marketing campaign to start tracking your performance.
                              </DialogDescription>
                            </DialogHeader>
                            <div className="grid gap-4 py-4">
                              <div className="space-y-2">
                                <Label htmlFor="name">Campaign Name</Label>
                                <Input id="name" name="name" placeholder="e.g., Summer Launch Campaign" required />
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="platform">Platform</Label>
                                <Select name="platform" required>
                                  <SelectTrigger>
                                    <SelectValue placeholder="Select platform" />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="facebook">Facebook</SelectItem>
                                    <SelectItem value="instagram">Instagram</SelectItem>
                                    <SelectItem value="facebook_instagram">Facebook & Instagram</SelectItem>
                                    <SelectItem value="google_ads">Google Ads</SelectItem>
                                    <SelectItem value="email">Email Marketing</SelectItem>
                                    <SelectItem value="linkedin">LinkedIn</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="budget">Budget ($)</Label>
                                <Input id="budget" name="budget" type="number" placeholder="1000" required />
                              </div>
                              <div className="space-y-2">
                                <Label htmlFor="status">Status</Label>
                                <Select name="status" defaultValue="active">
                                  <SelectTrigger>
                                    <SelectValue />
                                  </SelectTrigger>
                                  <SelectContent>
                                    <SelectItem value="active">Active</SelectItem>
                                    <SelectItem value="paused">Paused</SelectItem>
                                  </SelectContent>
                                </Select>
                              </div>
                            </div>
                            <DialogFooter>
                              <Button 
                                type="submit" 
                                disabled={createCampaignMutation.isPending}
                                className="bg-egyptian-blue hover:bg-egyptian-navy"
                              >
                                {createCampaignMutation.isPending ? (
                                  <>
                                    <i className="fas fa-spinner fa-spin mr-2"></i>
                                    Creating...
                                  </>
                                ) : (
                                  "Create Campaign"
                                )}
                              </Button>
                            </DialogFooter>
                          </form>
                        </DialogContent>
                      </Dialog>
                    </div>
                  </CardHeader>
                  <CardContent className="p-0">
                    {campaignsLoading ? (
                      <div className="p-6 text-center">
                        <i className="fas fa-spinner fa-spin text-2xl text-egyptian-blue mb-4"></i>
                        <p className="text-gray-600">Loading campaigns...</p>
                      </div>
                    ) : campaigns.length === 0 ? (
                      <div className="p-12 text-center">
                        <div className="w-24 h-24 mx-auto mb-6 bg-gradient-to-br from-egyptian-gold to-warm-gold rounded-full flex items-center justify-center">
                          <i className="fas fa-rocket text-3xl text-white"></i>
                        </div>
                        <h3 className="text-2xl font-bold text-egyptian-gold mb-3">Ready to Launch?</h3>
                        <p className="text-gray-400 mb-8 max-w-md mx-auto leading-relaxed">
                          Create your first marketing campaign and start building your business presence in the Egyptian market.
                        </p>
                        <Button 
                          onClick={() => setIsCreateModalOpen(true)} 
                          className="bg-gradient-to-r from-egyptian-gold to-warm-gold hover:from-warm-gold hover:to-egyptian-gold text-black px-8 py-4 text-lg font-semibold rounded-xl shadow-lg transform hover:scale-105 transition-all duration-300"
                        >
                          <i className="fas fa-plus mr-3"></i>Create Your First Campaign
                        </Button>
                      </div>
                    ) : (
                      <div className="divide-y divide-egyptian-gold/20">
                        {(campaigns as Campaign[]).map((campaign: Campaign) => (
                          <div key={campaign.id} className="p-6 hover:bg-egyptian-gold/5 transition-colors">
                            <div className="flex items-center justify-between mb-3">
                              <div className="flex items-center space-x-3">
                                <div className={`w-3 h-3 rounded-full ${
                                  campaign.status === 'active' ? 'bg-green-500' : 
                                  campaign.status === 'paused' ? 'bg-yellow-500' : 'bg-gray-500'
                                }`}></div>
                                <h4 className="font-semibold text-egyptian-gold">{campaign.name}</h4>
                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                  campaign.status === 'active' ? 'bg-green-500/20 text-green-400' :
                                  campaign.status === 'paused' ? 'bg-yellow-500/20 text-yellow-400' :
                                  'bg-gray-500/20 text-gray-400'
                                }`}>
                                  {campaign.status}
                                </span>
                              </div>
                              <div className="text-sm text-gray-400">
                                Budget: {formatCurrency(campaign.budget)}
                              </div>
                            </div>
                            <p className="text-gray-400 text-sm mb-4">{campaign.description}</p>
                            <div className="grid grid-cols-3 gap-4 text-sm">
                              <div>
                                <p className="text-gray-500">Reach</p>
                                <p className="font-semibold text-egyptian-gold">{campaign.reach?.toLocaleString() || '0'}</p>
                              </div>
                              <div>
                                <p className="text-gray-500">Performance</p>
                                <div className="flex items-center space-x-2">
                                  <Progress value={campaign.performance || 0} className="w-full h-2" />
                                  <span className="font-semibold text-egyptian-gold">{campaign.performance || 0}%</span>
                                </div>
                              </div>
                              <div>
                                <p className="text-gray-500">End Date</p>
                                <p className="font-semibold text-egyptian-gold">{campaign.endDate?.toLocaleDateString() || 'N/A'}</p>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>

              {/* Quick Actions & Analytics */}
              <div className="space-y-6">
                {/* Quick Actions */}
                <Card className="shadow-lg bg-gray-900 border border-egyptian-gold/30">
                  <CardHeader>
                    <CardTitle className="text-lg font-semibold text-egyptian-gold">Quick Actions</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button 
                      onClick={() => setIsCreateModalOpen(true)}
                      className="w-full bg-egyptian-gold hover:bg-warm-gold text-black font-semibold"
                    >
                      <i className="fas fa-plus mr-2"></i>Create Campaign
                    </Button>
                    <Button 
                      onClick={() => exportCSVMutation.mutate()}
                      disabled={exportCSVMutation.isPending}
                      variant="outline" 
                      className="w-full border-2 border-egyptian-gold text-egyptian-gold hover:bg-egyptian-gold hover:text-black"
                    >
                      {exportCSVMutation.isPending ? (
                        <i className="fas fa-spinner fa-spin mr-2"></i>
                      ) : (
                        <i className="fas fa-file-export mr-2"></i>
                      )}
                      Export All Data
                    </Button>
                    <Button variant="outline" className="w-full border-2 border-egyptian-gold text-egyptian-gold hover:bg-egyptian-gold hover:text-black">
                      <i className="fas fa-chart-line mr-2"></i>View Analytics
                    </Button>
                  </CardContent>
                </Card>

                {/* Success Tips */}
                <Card className="shadow-lg bg-gray-900 border border-egyptian-gold/30">
                  <CardHeader>
                    <CardTitle className="text-lg font-semibold text-egyptian-gold flex items-center">
                      <i className="fas fa-lightbulb text-egyptian-gold mr-2"></i>
                      Success Tips
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-4 bg-gradient-to-r from-egyptian-gold/10 to-warm-gold/10 rounded-lg border border-egyptian-gold/20">
                      <h4 className="font-semibold text-egyptian-gold mb-2">Start Strong</h4>
                      <p className="text-sm text-gray-300">Create your first campaign with a clear target audience and compelling message.</p>
                    </div>
                    <div className="p-4 bg-gradient-to-r from-egyptian-gold/5 to-warm-gold/5 rounded-lg border border-egyptian-gold/20">
                      <h4 className="font-semibold text-egyptian-gold mb-2">Track Progress</h4>
                      <p className="text-sm text-gray-300">Monitor your campaign performance and adjust strategies for optimal results.</p>
                    </div>
                    <div className="p-4 bg-gradient-to-r from-egyptian-gold/5 to-warm-gold/5 rounded-lg border border-egyptian-gold/20">
                      <h4 className="font-semibold text-egyptian-gold mb-2">Scale Smart</h4>
                      <p className="text-sm text-gray-300">Use data insights to expand successful campaigns and reach new markets.</p>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </section>
      </div>

      <ChatWidget user={user} />
    </div>
  );
}
