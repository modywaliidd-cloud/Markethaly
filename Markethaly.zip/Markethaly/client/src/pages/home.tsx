import { User } from "@shared/schema";
import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import BusinessProfile from "@/components/business-profile";
import DataExport from "@/components/data-export";
import ChatWidget from "@/components/chat-widget";
import Logo from "@/components/logo";
import { Link } from "wouter";

interface HomeProps {
  user: User | null;
  onLogout: () => void;
}

export default function Home({ user, onLogout }: HomeProps) {
  return (
    <div className="min-h-screen dark-bg">
      <Navigation user={user} onLogout={onLogout} />
      <HeroSection user={user} />
      <BusinessProfile />
      <DataExport />
      
      {/* Footer */}
      <footer className="bg-egyptian-navy text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <Logo size="md" />
                <h3 className="text-2xl font-bold text-egyptian-gold">Markethaly</h3>
              </div>
              <p className="text-gray-300 mb-4">Empowering Egyptian startups with premium marketing campaign management solutions.</p>
              <div className="flex space-x-4">
                <a href="#" className="text-gray-300 hover:text-egyptian-gold transition-colors">
                  <i className="fab fa-facebook text-xl"></i>
                </a>
                <a href="#" className="text-gray-300 hover:text-egyptian-gold transition-colors">
                  <i className="fab fa-twitter text-xl"></i>
                </a>
                <a href="#" className="text-gray-300 hover:text-egyptian-gold transition-colors">
                  <i className="fab fa-linkedin text-xl"></i>
                </a>
              </div>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Platform</h4>
              <ul className="space-y-2 text-gray-300">
                <li><Link href="/dashboard" className="hover:text-white transition-colors">Dashboard</Link></li>
                <li><a href="#" className="hover:text-white transition-colors">Campaigns</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Analytics</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Export Tools</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-300">
                <li><a href="#" className="hover:text-white transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-white transition-colors">API Documentation</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Community</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Company</h4>
              <ul className="space-y-2 text-gray-300">
                <li><a href="#" className="hover:text-white transition-colors">About Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Careers</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-12 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Markethaly. All rights reserved. Made with ❤️ in Egypt.</p>
          </div>
        </div>
      </footer>

      <ChatWidget user={user} />
    </div>
  );
}
