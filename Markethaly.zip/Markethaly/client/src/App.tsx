import { Switch, Route, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useState, useEffect } from "react";
import { User } from "@shared/schema";

import Home from "@/pages/home";
import Login from "@/pages/login";
import Register from "@/pages/register";
import Dashboard from "@/pages/dashboard";
import Services from "@/pages/services";
import Portfolio from "@/pages/portfolio";
import Contact from "@/pages/contact";
import NotFound from "@/pages/not-found";

function Router() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check if user is stored in localStorage
    const storedUser = localStorage.getItem('markethaly_user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
    setLoading(false);
  }, []);

  const login = (user: User) => {
    setUser(user);
    localStorage.setItem('markethaly_user', JSON.stringify(user));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('markethaly_user');
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-egyptian-blue"></div>
      </div>
    );
  }

  return (
    <Switch>
      <Route path="/" component={() => <Home user={user} onLogout={logout} />} />
      <Route path="/login" component={() => user ? <Redirect to="/dashboard" /> : <Login onLogin={login} />} />
      <Route path="/register" component={() => user ? <Redirect to="/dashboard" /> : <Register onLogin={login} />} />
      <Route path="/dashboard" component={() => user ? <Dashboard user={user} onLogout={logout} /> : <Redirect to="/login" />} />
      <Route path="/services" component={() => <Services user={user} onLogout={logout} />} />
      <Route path="/portfolio" component={() => <Portfolio user={user} onLogout={logout} />} />
      <Route path="/contact" component={() => <Contact user={user} onLogout={logout} />} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
