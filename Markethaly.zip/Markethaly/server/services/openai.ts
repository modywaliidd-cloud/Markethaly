// Preset responses for chatbot without OpenAI
const marketingResponses = {
  greetings: [
    "Hello! I'm your Markethaly assistant. How can I help you optimize your marketing campaigns today?",
    "Welcome to Markethaly! I'm here to help you with your marketing questions.",
    "Hi there! Ready to boost your marketing performance? What can I help you with?"
  ],
  campaigns: [
    "For effective campaigns, focus on clear objectives, target audience research, and consistent messaging across platforms.",
    "Consider starting with Facebook and Instagram ads for the Egyptian market - they have excellent targeting options for local businesses.",
    "A good campaign budget allocation is 70% for proven strategies and 30% for testing new approaches."
  ],
  analytics: [
    "Track key metrics like reach, engagement rate, conversions, and ROI. Focus on metrics that align with your business goals.",
    "Use our export feature to analyze your data in Excel. Look for trends in performance across different platforms.",
    "A healthy conversion rate for most businesses is 2-5%. If you're below 1%, consider optimizing your landing pages."
  ],
  general: [
    "That's a great question about marketing strategy. Consider your target audience and business goals when planning campaigns.",
    "For Egyptian businesses, local cultural preferences and timing can significantly impact campaign performance.",
    "I recommend starting with small test budgets to validate your approach before scaling up your campaigns."
  ]
};

export async function generateChatResponse(message: string, context?: string): Promise<string> {
  const lowerMessage = message.toLowerCase();
  
  // Simple keyword-based response matching
  if (lowerMessage.includes('hello') || lowerMessage.includes('hi') || lowerMessage.includes('hey')) {
    return getRandomResponse(marketingResponses.greetings);
  }
  
  if (lowerMessage.includes('campaign') || lowerMessage.includes('ad') || lowerMessage.includes('marketing')) {
    return getRandomResponse(marketingResponses.campaigns);
  }
  
  if (lowerMessage.includes('analytics') || lowerMessage.includes('data') || lowerMessage.includes('performance') || lowerMessage.includes('metrics')) {
    return getRandomResponse(marketingResponses.analytics);
  }
  
  if (lowerMessage.includes('help') || lowerMessage.includes('how') || lowerMessage.includes('what')) {
    return "I can help you with marketing campaigns, analytics, data export, and Egyptian market insights. What specific area would you like to explore?";
  }
  
  return getRandomResponse(marketingResponses.general);
}

function getRandomResponse(responses: string[]): string {
  return responses[Math.floor(Math.random() * responses.length)];
}

export async function generateCampaignSuggestions(businessType: string, budget: number, targetAudience: string): Promise<{
  suggestions: string[];
  optimizations: string[];
}> {
  // Preset suggestions based on common Egyptian market patterns
  const suggestions = [
    "Focus on Facebook and Instagram for maximum reach in Egypt",
    "Use Arabic content alongside English for broader appeal",
    "Target Cairo, Alexandria, and Giza for urban demographics",
    "Schedule posts during evening hours (7-10 PM) for best engagement",
    "Include local landmarks and cultural references in visuals"
  ];
  
  const optimizations = [
    "Test different ad creative approaches weekly",
    "Monitor performance metrics closely and adjust budgets",
    "Use A/B testing for different audience segments",
    "Optimize for mobile users (90% of Egyptian internet users)",
    "Track conversion rates and adjust targeting accordingly"
  ];
  
  return {
    suggestions: suggestions.slice(0, 3), // Return 3 suggestions
    optimizations: optimizations.slice(0, 3), // Return 3 optimizations
  };
}
